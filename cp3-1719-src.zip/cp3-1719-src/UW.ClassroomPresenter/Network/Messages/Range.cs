// $Id: Range.cs 348 2005-07-28 01:45:12Z pediddle $

using System;

namespace UW.ClassroomPresenter.Network.Messages {

    /*
    internal struct Set {
        private Range[] foo;
    }

    internal struct Range {
        public ulong Start;
        public ulong End;
    }
    */
}
