using System;
using System.Collections.Generic;
using System.Text;

namespace UW.ClassroomPresenter.Network.TCP {
    [Serializable]
    class TCPHeartbeatMessage {
    }
}
