// $Id: LassoStylusModel.cs 367 2005-07-30 07:43:28Z pediddle $

using System;

namespace UW.ClassroomPresenter.Model.Stylus {
    public class LassoStylusModel : StylusModel {
        public LassoStylusModel(Guid id) : base(id) {
        }
    }
}
