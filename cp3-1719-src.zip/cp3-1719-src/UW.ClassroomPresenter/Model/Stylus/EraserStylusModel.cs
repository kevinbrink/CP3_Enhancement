// $Id: EraserStylusModel.cs 367 2005-07-30 07:43:28Z pediddle $

using System;

namespace UW.ClassroomPresenter.Model.Stylus {
    public class EraserStylusModel : StylusModel {
        public EraserStylusModel(Guid id) : base(id) {
        }
    }
}
