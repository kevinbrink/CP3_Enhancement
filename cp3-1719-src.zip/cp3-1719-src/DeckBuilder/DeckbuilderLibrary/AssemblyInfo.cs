using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("DeckBuilder 3.0: Libraries")]
[assembly: AssemblyDescription("Revision 1719 ; 2008/08/21 17:13:10; https://assab.cs.washington.edu/svn/trunk/DeckBuilder/DeckbuilderLibrary")]
// [assembly: AssemblyConfiguration(...)]
[assembly: AssemblyCompany("University of Washington, Department of Computer Science and Engineering")]
[assembly: AssemblyProduct("Classroom Presenter 3")]
[assembly: AssemblyCopyright("(c) 2006.  All Rights Reserved.  See http://www.cs.washington.edu/education/dl/presenter/ for details.")]
// [assembly: AssemblyTrademark(...)]
// [assembly: AssemblyCulture(...)]	
[assembly: AssemblyVersion("3.0.1641.*")]
[assembly: AssemblyDelaySign(false)]
// [assembly: AssemblyKeyFile(...)]
// [assembly: AssemblyKeyName(...)]

