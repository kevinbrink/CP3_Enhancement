COMPILING
---------
To compile you need to copy each folder from the packages directory into the following directory:

For Visual Studio 2005 Professional, Team Suite, other Team Editions:
C:\Program Files\Microsoft Visual Studio 8\SDK\v2.0\BootStrapper\Packages\

For Visual Studio 2008 Beta 2:
C:\Program Files\Microsoft SDKs\GenericBootStrapper\Packages\

Else:
C:\Program Files\Microsoft.NET\SDK\v2.0\BootStrapper\Packages\

Additionally, on the development machine, the user should install the Visual Studio 
Tools for Office Second Edition (VSTO 2005 SE):
http://www.microsoft.com/downloads/details.aspx?familyid=5e86cab3-6fd6-4955-
b979-e1676db6b3cb&displaylang=en

OTHER NOTES
-----------
The password for the keyfile used to sign the plugin (Office2007InstructorModeAddinKey.pfx) is: Ybz357!_#
