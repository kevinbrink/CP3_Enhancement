Test Decks for Classroom Presenter 3.0

Multilayer - Test deck with backgrounds and all modes (instructor/student etc.)
Affine    - non-standard aspect ratio
HuffmanDemo - 10 slide deck from class, 144K
UnionFind - 19 slide deck from class, 100K
Test - Simple slide deck that includes all modes (instructor/student etc.)
TestWithBkg - Test with a fancy background

The CP3 directory contains the converted files.  However, we may break compatibility between builds on the file format - so we will generate new versions when this happens.

Last updated 6-24-06,  Deckbuilder 2.7.876