Test Cases

CP3 files for testing presenter (possibly along with PPT files)  The version of CP3 should be recorded

ESL.cp3, ESL.ppt  (CP3 version 1099)
Files for a talk 8-10-06.  In testings slides 2, 3, and n-1 had trouble being recieved.

